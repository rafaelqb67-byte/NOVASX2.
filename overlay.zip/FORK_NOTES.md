# NovaSX2 — fork do ARMSX2 (menu redesenhado)

Fork de https://github.com/ARMSX2/ARMSX2, que por sua vez é baseado no PCSX2.
Licença: GPLv3 (mantenha o arquivo COPYING.GPLv3 e os avisos de copyright originais).
Se distribuir o app compilado, você deve disponibilizar o código-fonte das suas modificações sob a mesma licença
e manter os créditos ao ARMSX2 e ao PCSX2 (por exemplo, na tela "Sobre" e no README).

## O que mudou
- Menu: a gaveta lateral foi substituída por um painel em grade que sobe de baixo (`navigation/NavigationHub.kt`).
  Todas as entradas, ações e destinos são os mesmos; suporte a controle (`controllerFocusable`) mantido.
- Visual: paleta carvão + âmbar/turquesa (`ui/theme/Color.kt`, `Theme.kt`) no lugar do azul-marinho.
- Nome do app: NovaSX2 (`strings.xml`, `ArmsComponents.kt`); applicationId padrão: `com.novasx2` (`build.gradle.kts`).
- Núcleo do emulador (JIT, renderizadores, input, saves etc.) intocado.

## Como aplicar
Copie o conteúdo desta pasta por cima do projeto ARMSX2-master mantendo os caminhos e compile o módulo Android.
Não consegui compilar aqui (sem SDK/rede): se o Gradle acusar erro, me envie o log.
